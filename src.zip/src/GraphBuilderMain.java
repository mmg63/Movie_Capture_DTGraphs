// File: GraphBuilderMain.java

import graphbuilder.*;
import javax.imageio.ImageIO;
import graphbuilder.ImageUtils;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


/**
 * Entry point: Processes all images in a folder and applies VoronoiGraphBuilder.
 */
public class GraphBuilderMain {

    public static void main(String[] args) throws Exception {
        String folderPath = "./src"; // Update this path to your image folder
        int numSuperpixels = 1024;
        double compactness = 0.5;

        File folder = new File(folderPath);
        File[] imageFiles = folder.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png"));

        if (imageFiles == null || imageFiles.length == 0) {
            System.out.println("No image files found in folder: " + folderPath);
            return;
        }

        List<Long> timings = new ArrayList<>();
        long totalStart = System.currentTimeMillis();

        for (File imgFile : imageFiles) {
            System.out.println("Processing: " + imgFile.getName());
            BufferedImage inputImg = ImageIO.read(imgFile);

            double[][][] labImage = ImageUtils.convertToLABNormalized(inputImg);
            long start = System.currentTimeMillis();

            SegmentationResult seg = Segmenter.segment(labImage, numSuperpixels, compactness, false);
            GraphData graph = DelaunayGraphBuilder.build(seg);

            long end = System.currentTimeMillis();
            timings.add(end - start);
            System.out.println("Graph built: " + graph.x.length + " nodes, time = " + (end - start) + " ms\n");
        }

        long totalEnd = System.currentTimeMillis();
        System.out.println("Total images processed: " + timings.size());
        System.out.println("Total time: " + (totalEnd - totalStart) + " ms");
        double avgTime = timings.stream().mapToLong(Long::longValue).average().orElse(0);
        System.out.println("Average time per image: " + avgTime + " ms");
    }
}
