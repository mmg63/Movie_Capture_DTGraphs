// File: ImageUtils.java
package graphbuilder;

import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;

/**
 * Utility class for image conversion and normalization.
 */
public class ImageUtils {

    /**
     * Converts an RGB BufferedImage to a normalized LAB image [H][W][3].
     * Assumes input is in sRGB (standard JPEG/PNG).
     * Output is min-max normalized per channel.
     */
    public static double[][][] convertToLABNormalized(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        double[][][] lab = new double[height][width][3];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb = image.getRGB(x, y);
                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;

                double[] labPixel = rgbToLab(r, g, b);
                lab[y][x][0] = labPixel[0] / 100.0; // L in [0,100] → [0,1]
                lab[y][x][1] = (labPixel[1] + 128.0) / 255.0; // A in [-128,127] → [0,1]
                lab[y][x][2] = (labPixel[2] + 128.0) / 255.0; // B in [-128,127] → [0,1]
            }
        }

        return lab;
    }

    /**
     * Converts RGB (0–255) to LAB using D65 white point.
     */
    private static double[] rgbToLab(int r, int g, int b) {
        // sRGB → XYZ
        double rr = gammaCorrect(r / 255.0);
        double gg = gammaCorrect(g / 255.0);
        double bb = gammaCorrect(b / 255.0);

        double X = rr * 0.4124 + gg * 0.3576 + bb * 0.1805;
        double Y = rr * 0.2126 + gg * 0.7152 + bb * 0.0722;
        double Z = rr * 0.0193 + gg * 0.1192 + bb * 0.9505;

        // Normalize by D65 reference white
        X /= 0.95047;
        Y /= 1.00000;
        Z /= 1.08883;

        double fx = fXYZ(X);
        double fy = fXYZ(Y);
        double fz = fXYZ(Z);

        double L = 116 * fy - 16;
        double a = 500 * (fx - fy);
        double bVal = 200 * (fy - fz);

        return new double[]{L, a, bVal};
    }

    private static double gammaCorrect(double c) {
        return (c <= 0.04045) ? (c / 12.92) : Math.pow((c + 0.055) / 1.055, 2.4);
    }

    private static double fXYZ(double t) {
        return (t > 0.008856) ? Math.cbrt(t) : (7.787 * t + 16.0 / 116.0);
    }
} 
