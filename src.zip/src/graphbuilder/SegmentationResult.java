// File: SegmentationResult.java
package graphbuilder;

/**
 * Holds all the raw outputs of the SNIC segmentation process.
 */
public class SegmentationResult {

    public int[] labels; // 1D array [H*W]
    public int width;
    public int height;
    public int numSuperpixels;
    public double[] kx, ky;         // Centroid X and Y
    public double[] ksize;          // Superpixel sizes
    public double[] kc_flat;        // Flattened LAB color array (C * numSuperpixels)
    public double[] std, cov;       // Standard deviation and covariance
    public int[] boundaries;        // Boundary mask [H*W]

    public SegmentationResult(int[] labels, int width, int height, int numSuperpixels,
                               double[] kx, double[] ky, double[] ksize,
                               double[] kc_flat, double[] std, double[] cov, int[] boundaries) {
        this.labels = labels;
        this.width = width;
        this.height = height;
        this.numSuperpixels = numSuperpixels;
        this.kx = kx;
        this.ky = ky;
        this.ksize = ksize;
        this.kc_flat = kc_flat;
        this.std = std;
        this.cov = cov;
        this.boundaries = boundaries;
    }
} 
