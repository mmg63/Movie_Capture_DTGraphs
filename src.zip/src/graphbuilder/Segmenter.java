// File: Segmenter.java
package graphbuilder;

import snic.SNICMain;

/**
 * Wrapper class to apply SNIC segmentation and return raw output arrays
 */
public class Segmenter {

    /**
     * Runs SNIC segmentation and returns a segmentation result object
     *
     * @param image 3D array [H][W][C] in LAB normalized format
     * @param numSuperpixels number of SNIC superpixels
     * @param compactness compactness value (default ~0.5-1.0)
     * @param doRGBtoLAB whether to convert RGB to LAB inside SNIC
     * @return result structure holding label matrix, centroids, etc.
     */
    public static SegmentationResult segment(double[][][] image, int numSuperpixels,
                                             double compactness, boolean doRGBtoLAB) {

        int height = image.length;
        int width = image[0].length;
        int channels = image[0][0].length;
        int sz = width * height;

        // Flatten image to 1D [C * sz] format for SNICMain
        double[] imgData = new double[sz * channels];
        for (int c = 0; c < channels; c++) {
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    imgData[c * sz + y * width + x] = image[y][x][c];
                }
            }
        }

        int[] labels = new int[sz];
        int[] numLabels = new int[1];
        double[] kx = new double[numSuperpixels];
        double[] ky = new double[numSuperpixels];
        double[] ksize = new double[numSuperpixels];
        double[] kc_flat = new double[numSuperpixels * channels];
        int[] boundaries = new int[sz];
        double[] kstd = new double[numSuperpixels];
        double[] kcov = new double[numSuperpixels];

        SNICMain.run(imgData, width, height, channels, numSuperpixels,
                     compactness, doRGBtoLAB,
                     labels, numLabels, kx, ky, ksize, kc_flat, boundaries, kstd, kcov);

        return new SegmentationResult(labels, width, height, numLabels[0], kx, ky, ksize, kc_flat, kstd, kcov, boundaries);
    }
} 
