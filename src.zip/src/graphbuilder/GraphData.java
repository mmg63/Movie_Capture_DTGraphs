// File: GraphData.java
package graphbuilder;

/**
 * A simple POJO for holding graph components in raw form,
 * extracted from SNIC + Voronoi processing.
 */
public class GraphData {

    /**
     * Node features [num_nodes][7] = (y, x, lab1, lab2, lab3, std, cov)
     */
    public double[][] x;

    /**
     * 2D edge list [2][num_edges], similar to PyTorch Geometric's edge_index
     * edgeIndex[0][i] = source node, edgeIndex[1][i] = target node
     */
    public int[][] edgeIndex;

    /**
     * Node spatial positions [num_nodes][2] = (y, x)
     */
    public double[][] pos;

    public GraphData(int numNodes, int numEdges) {
        this.x = new double[numNodes][7];
        this.pos = new double[numNodes][2];
        this.edgeIndex = new int[2][numEdges];
    }

    public GraphData(double[][] x, int[][] edgeIndex, double[][] pos) {
        this.x = x;
        this.edgeIndex = edgeIndex;
        this.pos = pos;
    }
} 
