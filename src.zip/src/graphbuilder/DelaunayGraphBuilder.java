// File: VoronoiGraphBuilder.java
package graphbuilder;

import java.util.*;

/**
 * Constructs graph data (x, edge_index, pos) from SNIC segmentation.
 */
public class DelaunayGraphBuilder {

    /**
     * Build the graph from a segmented image.
     */
    public static GraphData build(SegmentationResult seg) {
        int H = seg.height;
        int W = seg.width;
        int numNodes = seg.numSuperpixels;

        double[][] x = new double[numNodes][7];
        double[][] pos = new double[numNodes][2];
        Map<Integer, Integer> labelToIndex = new HashMap<>();

        // Map label → index and populate x/pos arrays
        for (int i = 0; i < numNodes; i++) {
            int label = i;
            labelToIndex.put(label, i);
            x[i][0] = seg.ky[i];
            x[i][1] = seg.kx[i];
            x[i][2] = seg.kc_flat[i];
            x[i][3] = seg.kc_flat[numNodes + i];
            x[i][4] = seg.kc_flat[2 * numNodes + i];
            x[i][5] = seg.std[i];
            x[i][6] = seg.cov[i];
            pos[i][0] = seg.ky[i];
            pos[i][1] = seg.kx[i];
        }

        // Create edge_index based on boundary pixel neighborhood
        Set<String> edgeSet = new HashSet<>();
        int[] dx = {-1, 0, 1, 0, -1, 1, 1, -1};
        int[] dy = {0, -1, 0, 1, -1, -1, 1, 1};

        for (int idx = 0; idx < seg.boundaries.length; idx++) {
            if (seg.boundaries[idx] != 1) continue;
            int xPix = idx % W;
            int yPix = idx / W;

            if (xPix < 1 || xPix >= W - 1 || yPix < 1 || yPix >= H - 1) continue;

            int centerLabel = seg.labels[idx];

            for (int d = 0; d < dx.length; d += 2) {
                int nx1 = xPix + dx[d];
                int ny1 = yPix + dy[d];
                int nx2 = xPix + dx[d + 1];
                int ny2 = yPix + dy[d + 1];

                int ni1 = ny1 * W + nx1;
                int ni2 = ny2 * W + nx2;
                if (ni1 < 0 || ni2 < 0 || ni1 >= seg.labels.length || ni2 >= seg.labels.length)
                    continue;

                int l1 = seg.labels[ni1];
                int l2 = seg.labels[ni2];
                if (l1 != l2 && l1 != centerLabel && l2 != centerLabel) {
                    String edge1 = l1 + "," + l2;
                    String edge2 = l2 + "," + l1;
                    edgeSet.add(edge1);
                    edgeSet.add(edge2);
                }
            }
        }

        // Convert edge set to array
        int[][] edgeIndex = new int[2][edgeSet.size()];
        int ei = 0;
        for (String edge : edgeSet) {
            String[] parts = edge.split(",");
            edgeIndex[0][ei] = Integer.parseInt(parts[0]);
            edgeIndex[1][ei] = Integer.parseInt(parts[1]);
            ei++;
        }

        return new GraphData(x, edgeIndex, pos);
    }
} 
