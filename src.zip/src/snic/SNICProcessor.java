// File: SNICProcessor.java
package snic;

import java.awt.Point;
import java.util.ArrayList;

/**
 * Core SNIC algorithm implementation handling superpixel assignment.
 */
public class SNICProcessor {

    public void run(double[][] chans, int nchans, int width, int height,
                    int[] labels, int[] outNumLabels, int inNumK, double compactness,
                    double[] kx, double[] ky, double[] ksize,
                    double[] kc_flat, double[] std, double[] cov) {

        int sz = width * height;
        int[] dx = {-1, 0, 1, 0};
        int[] dy = {0, -1, 0, 1};
        int[] offset = {-1, -width, 1, width};

        ArrayList<Point> seeds = SeedFinder.findSeeds(width, height, inNumK);
        int numk = seeds.size();
        outNumLabels[0] = numk;

        for (int i = 0; i < sz; i++) labels[i] = -1;

        Heap heap = new Heap();
        for (int k = 0; k < numk; k++) {
            Point p = seeds.get(k);
            heap.push((p.x << 16) | p.y, k, 0.0);
        }

        double[][] kc = new double[nchans][numk];
        double[] count = new double[numk];

        int pixelCount = 0;
        double invwt = (compactness * compactness * numk) / (double) sz;

        while (!heap.isEmpty() && pixelCount < sz) {
            Node node = heap.pop();
            if (node == null) break;

            int x = (node.index >> 16) & 0xFFFF;
            int y = node.index & 0xFFFF;
            int i = y * width + x;

            if (labels[i] != -1) continue;

            int k = node.label;
            labels[i] = k;
            pixelCount++;

            for (int c = 0; c < nchans; c++) kc[c][k] += chans[c][i];
            kx[k] += x;
            ky[k] += y;
            count[k]++;

            for (int d = 0; d < 4; d++) {
                int xx = x + dx[d];
                int yy = y + dy[d];
                if (xx < 0 || xx >= width || yy < 0 || yy >= height) continue;

                int ni = i + offset[d];
                if (labels[ni] != -1) continue;

                double colorDist = 0.0;
                for (int c = 0; c < nchans; c++) {
                    double avg = kc[c][k] / count[k];
                    double diff = chans[c][ni] - avg;
                    colorDist += diff * diff;
                }

                double xAvg = kx[k] / count[k];
                double yAvg = ky[k] / count[k];
                double dx2 = (xx - xAvg);
                double dy2 = (yy - yAvg);
                double spatialDist = dx2 * dx2 + dy2 * dy2;

                double dist = colorDist + invwt * spatialDist;
                heap.push((xx << 16) | yy, k, dist);
            }
        }

        for (int k = 0; k < numk; k++) {
            if (count[k] == 0) continue;
            kx[k] /= count[k];
            ky[k] /= count[k];
            ksize[k] = count[k];
            for (int c = 0; c < nchans; c++) {
                kc_flat[c * numk + k] = kc[c][k] / count[k];
            }
            std[k] = 0.0; // Placeholder for std calculation
            cov[k] = 0.0; // Placeholder for cov calculation
        }
    }
} 
