// File: SNICMain.java
package snic;

/**
 * High-level SNIC interface combining RGB conversion, SNIC execution, and boundary detection.
 */
public class SNICMain {

    public static void run(double[] img, int width, int height, int nchans, int numSuperpixels,
                           double compactness, boolean convertToLab,
                           int[] labels, int[] numLabels,
                           double[] kx, double[] ky, double[] ksize,
                           double[] kc_flat, int[] boundaries,
                           double[] kstd, double[] kcov) {

        int sz = width * height;
        double[][] chans = new double[nchans][sz];

        for (int c = 0; c < nchans; c++) {
            System.arraycopy(img, c * sz, chans[c], 0, sz);
        }

        if (convertToLab && nchans == 3) {
            RGBToLabConverter.convert(chans[0], chans[1], chans[2],
                                      chans[0], chans[1], chans[2], sz);
        }

        SNICProcessor processor = new SNICProcessor();
        processor.run(chans, nchans, width, height,
                      labels, numLabels, numSuperpixels, compactness,
                      kx, ky, ksize, kc_flat, kstd, kcov);

        BoundaryDetector.detect(labels, width, height, boundaries);
    }
} 
