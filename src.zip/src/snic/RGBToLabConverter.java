package snic;

/**
 * Utility class for converting RGB image channels to CIELAB color space.
 */
public class RGBToLabConverter {

    public static void convert(double[] r, double[] g, double[] b,
                               double[] l, double[] a, double[] bb, int size) {
        final double epsilon = 0.008856;
        final double kappa = 903.3;
        final double Xr = 0.950456;
        final double Yr = 1.0;
        final double Zr = 1.088754;

        for (int i = 0; i < size; i++) {
            double R = r[i] / 255.0;
            double G = g[i] / 255.0;
            double B = b[i] / 255.0;

            double rLin = (R <= 0.04045) ? R / 12.92 : Math.pow((R + 0.055) / 1.055, 2.4);
            double gLin = (G <= 0.04045) ? G / 12.92 : Math.pow((G + 0.055) / 1.055, 2.4);
            double bLin = (B <= 0.04045) ? B / 12.92 : Math.pow((B + 0.055) / 1.055, 2.4);

            double X = rLin * 0.4124564 + gLin * 0.3575761 + bLin * 0.1804375;
            double Y = rLin * 0.2126729 + gLin * 0.7151522 + bLin * 0.0721750;
            double Z = rLin * 0.0193339 + gLin * 0.1191920 + bLin * 0.9503041;

            double xr = X / Xr;
            double yr = Y / Yr;
            double zr = Z / Zr;

            double fx = (xr > epsilon) ? Math.cbrt(xr) : (kappa * xr + 16.0) / 116.0;
            double fy = (yr > epsilon) ? Math.cbrt(yr) : (kappa * yr + 16.0) / 116.0;
            double fz = (zr > epsilon) ? Math.cbrt(zr) : (kappa * zr + 16.0) / 116.0;

            l[i] = 116.0 * fy - 16.0;
            a[i] = 500.0 * (fx - fy);
            bb[i] = 200.0 * (fy - fz);
        }
    }
} 