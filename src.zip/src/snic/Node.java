package snic;

// Represents a pixel node in the SNIC heap with its index, cluster label, and distance.
public class Node {
	public int index;  // pixel index as a packed int: (x << 16 | y)
	public int label;  // cluster label
	public double dist;  // Distance to a cluster center
	
	public Node(int index, int label, double dist) {
		this.index = index;
		this.label = label;
		this.dist = dist;
	}
}