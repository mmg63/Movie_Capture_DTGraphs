package snic;

import java.util.ArrayList;
import java.awt.Point;

/**
 * Utility for finding initial seed positions in a grid for SNIC clustering.
 */
public class SeedFinder {

    /**
     * Finds seed coordinates on a grid that approximates the desired number of superpixels.
     *
     * @param width  image width
     * @param height image height
     * @param numk   desired number of superpixels
     * @return       list of seed points (x, y)
     */
    public static ArrayList<Point> findSeeds(int width, int height, int numk) {
        int sz = width * height;
        double gridStep = Math.sqrt((double) sz / numk) + 0.5;

        int minErr = Integer.MAX_VALUE;
        for (double x = gridStep - 1.0; x <= gridStep + 1.0; x += 0.1) {
            int err = Math.abs((int)(0.5 + width / x) * (int)(0.5 + height / x) - numk);
            if (err < minErr) {
                minErr = err;
                gridStep = x;
            }
        }

        ArrayList<Point> seeds = new ArrayList<>();
        double halfStep = gridStep / 2.0;
        for (double y = halfStep; y <= height; y += gridStep) {
            int yval = (int) (y + 0.5);
            if (yval < height) {
                for (double x = halfStep; x <= width; x += gridStep) {
                    int xval = (int) (x + 0.5);
                    if (xval < width) {
                        seeds.add(new Point(xval, yval));
                    }
                }
            }
        }
        return seeds;
    }
} 
