// File: DelaunayTriangulation.java
package snic;

/**
 * Constructs a Delaunay-like adjacency based on superpixel labels and their centroids.
 */
public class DelaunayTriangulation {

    public static void compute(int width, int height,
                               int[] labels, double[] kx, double[] ky, int numk,
                               int[] boundaries, int[] labelToCentroids, int[] edgeLabels) {

        int sz = width * height;
        int[] dx8 = {-1, 0, 1, 0, -1, 1, 1, -1};
        int[] dy8 = {0, -1, 0, 1, -1, -1, 1, 1};

        for (int i = 0; i < numk; i++) {
            int index = (int) (ky[i]) * width + (int) (kx[i]);
            int label = labels[index];
            labelToCentroids[i] = label;
            labelToCentroids[numk + i] = (int) kx[i];
            labelToCentroids[2 * numk + i] = (int) ky[i];
        }

        int edgeCount = 0;
        for (int i = 0; i < sz; i++) {
            if (boundaries[i] != 0) {
                int x = i % width;
                int y = i / width;
                for (int d = 0; d < 8; d++) {
                    int xx = x + dx8[d];
                    int yy = y + dy8[d];
                    if (xx >= 0 && xx < width && yy >= 0 && yy < height) {
                        int neighborIdx = yy * width + xx;
                        int reg1 = labels[i];
                        int reg2 = labels[neighborIdx];
                        if (reg1 != reg2) {
                            edgeLabels[edgeCount] = reg1;
                            edgeLabels[8 * numk + edgeCount] = reg2;
                            edgeCount++;
                        }
                    }
                }
            }
        }
    }
} 
