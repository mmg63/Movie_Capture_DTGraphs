package snic;

import java.util.ArrayList;

/**
 * Min-heap priority queue for managing pixel nodes during SNIC clustering.
 */
public class Heap {
    private final ArrayList<Node> nodes;

    public Heap() {
        nodes = new ArrayList<>();
        nodes.add(null); // index 0 is unused to simplify parent/child calculations
    }

    public void push(int index, int label, double dist) {
        Node newNode = new Node(index, label, dist);
        nodes.add(newNode);
        int i = nodes.size() - 1;
        while (i > 1 && nodes.get(i / 2).dist > nodes.get(i).dist) {
            swap(i, i / 2);
            i /= 2;
        }
    }

    public Node pop() {
        if (nodes.size() <= 1) return null;
        Node top = nodes.get(1);
        Node last = nodes.remove(nodes.size() - 1);
        if (nodes.size() == 1) return top;

        nodes.set(1, last);
        int i = 1;
        while (true) {
            int left = 2 * i;
            int right = left + 1;
            int smallest = i;

            if (left < nodes.size() && nodes.get(left).dist < nodes.get(smallest).dist) {
                smallest = left;
            }
            if (right < nodes.size() && nodes.get(right).dist < nodes.get(smallest).dist) {
                smallest = right;
            }
            if (smallest == i) break;
            swap(i, smallest);
            i = smallest;
        }
        return top;
    }

    public boolean isEmpty() {
        return nodes.size() <= 1;
    }

    private void swap(int i, int j) {
        Node temp = nodes.get(i);
        nodes.set(i, nodes.get(j));
        nodes.set(j, temp);
    }
} 