// File: BoundaryDetector.java
package snic;

/**
 * Utility class to detect boundary pixels by comparing neighboring labels.
 */
public class BoundaryDetector {

    /**
     * Fills boundariesOut with 1 if the pixel differs from one of its 4-neighbors.
     */
    public static void detect(int[] labels, int width, int height, int[] boundariesOut) {
        int sz = width * height;
        int[] dx = {-1, 0, 1, 0};
        int[] dy = {0, -1, 0, 1};

        for (int i = 0; i < sz; i++) {
            boundariesOut[i] = 0;
            int x = i % width;
            int y = i / width;
            int myLabel = labels[i];
            for (int d = 0; d < 4; d++) {
                int xx = x + dx[d];
                int yy = y + dy[d];
                if (xx >= 0 && xx < width && yy >= 0 && yy < height) {
                    int neighborIndex = yy * width + xx;
                    if (labels[neighborIndex] != myLabel) {
                        boundariesOut[i] = 1;
                        break;
                    }
                }
            }
        }
    }
} 
